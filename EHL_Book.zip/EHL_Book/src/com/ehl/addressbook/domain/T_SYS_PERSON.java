package com.ehl.addressbook.domain;

import java.util.Date;

public class T_SYS_PERSON {
	private String id;
	private String name;
	private String sex;
	private String email;
	private String birthday;
}
